El dise�o de esta fuente surgi� de las 7 letras de mi marca (defharo), dibujadas originalmente en el 2011 con motivo del redise�o de mi logotipo.
The design of this font came from the 7 letters of my brand (defharo), originally drawn in 2011 to mark the redesign of my logo.
http://defharo.com/branding/identidad-corporativa/renovar-logotipo/

Lee el post completo sobre la creaci�n de esta fuente:
Read the full post on the creation of this font:
http://defharo.com/webfonts/la-chata-a-free-web-font/

Esta fuente se puede descargar en formato webfonts desde:
This font can be downloaded WebFonts format from:
http://defharo.com/webfonts/la-chata-a-free-web-font/

